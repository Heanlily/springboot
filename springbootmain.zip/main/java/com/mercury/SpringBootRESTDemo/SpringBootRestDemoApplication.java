package com.mercury.SpringBootRESTDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class SpringBootRestDemoApplication {

	public static void main(String[] args) {
		//automatically launch embedded tomcat server
		//and deploy your java web application on the tomcat server
		SpringApplication.run(SpringBootRestDemoApplication.class, args);
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		//higher strength means more difficult to hack
		return new BCryptPasswordEncoder(11);
	}
}
