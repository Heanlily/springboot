package com.mercury.SpringBootRESTDemo.service;

import com.mercury.SpringBootRESTDemo.bean.User;
import com.mercury.SpringBootRESTDemo.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.UnaryOperator;

@Service
public class UserService implements UserDetailsService {
    @Autowired
    UserDao userDao;

    @Autowired
    PasswordEncoder passwordEncoder;
    public List<User> getAllUser() {
        return userDao.findAll();
    }

    public boolean addOneUser(User user) {
        try {
            User existing = userDao.findByUsername(user.getUsername());
            if(existing == null) {
                //hash password before user is added to db
                user.setPassword(passwordEncoder.encode(user.getPassword()));
                userDao.save(user);
                return true;
            }else {
                return false;
            }

        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        return userDao.findByUsername(s);
    }
}
