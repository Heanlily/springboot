package com.mercury.SpringBootRESTDemo.service;

import com.mercury.SpringBootRESTDemo.bean.Sample;
import com.mercury.SpringBootRESTDemo.dao.SampleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

//wrap business logic: event handling, transaction management
@Service
public class SampleService {
    @Autowired
    SampleDao sampleDao;


    public List<Sample> getAllSamples() {
        return sampleDao.findAll();
    }


    @Transactional //wrap all the SQL generated within the method in one transaction
    //(rollback/commit)
    public boolean addOneSample(Sample sample) {
        //begin transaction
        try{
            Optional sampleInDB = sampleDao.findById(sample.getName());
            if(sampleInDB.isPresent()){
                return false;
            }else {
                sampleDao.save(sample);
                Sample sampleBackup = new Sample(sample.getName()+"_back up",sample.getAge());
                sampleDao.save(sampleBackup);
                return true;
            }
            //commit
        }catch (Exception e){
            return false;
            //rollback
        }


    }
}
