package com.mercury.SpringBootRESTDemo.service;

import com.mercury.SpringBootRESTDemo.bean.Product;
import com.mercury.SpringBootRESTDemo.dao.ProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    ProductDao productDao;

    public List<Product> getAllProducts() {
        return productDao.findAll();
    }

    public Product getOneProductById(long id) {
        return productDao.findById(id).orElse(new Product());
    }

    public List<Product> getProductsAboveMinPrice(int minPrice) {
        //as JPA to generate SQL with where statement to serach in DB
        return productDao.findByPriceGreaterThanEqual(minPrice);
    }

}
