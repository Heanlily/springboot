package com.mercury.SpringBootRESTDemo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MostExecutedServiceMethodAspect {
    //cross-cutting concern: which method excutes most in services?
    //advice: print method name when any method after any service executes
    //join point: when any service method is executed by our application

    @Pointcut("execution(* com.mercury.SpringBootRESTDemo.service.*Service.*(..))")
    public void getJoinPoint() {

    }

    //@Before: excute advice before method executes, @AfterReturning(return successfully)
    //@AfterThrowing: excute after method throws an exception
    //@After: execute after method excutes(no matter succeed or with exception)
    //@Around: can control how the original method will be executed.
    //you can do something around the method execution.
    @After("getJoinPoint()")
    public void printMethodNameAdvice(JoinPoint joinPoint) {
        System.out.print(joinPoint.getSignature().getName()+"is executed.(AOP)");
    }

}
