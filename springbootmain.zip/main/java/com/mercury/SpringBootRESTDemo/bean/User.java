package com.mercury.SpringBootRESTDemo.bean;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;
import java.util.Set;

@Entity
@Table(name = "MSI_USER")
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "MSI_USER_SEQ", allocationSize = 1)
    private long id;
    @Column
    private String username;
    @Column
    private String password;

    //relationship between User and user profile is many to many
    //but in order to avoid duplicates, we use join table to store the relationship
    //we have to provide this join table to JPA in order to let JPA to generate jpa(ROM)

    //join columns: how MSI_USER join "MSI_USER_MSI_USER_PROFILE"

    //inverseJoinColums: how MSI_USER_MSI_USER_PROFILE join MSI_USER_Profile
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "MSI_USER_MSI_USER_PROFILE",
            joinColumns = {@JoinColumn(name = "user_id",referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "user_profile_id",referencedColumnName = "id")}
    )
    private Set<UserProfile> profiles;

    public User() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<UserProfile> getProfiles() {
        return profiles;
    }

    public void setProfiles(Set<UserProfile> profiles) {
        this.profiles = profiles;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        //get all permissions of a user
        return profiles; //Set<UserProfile>
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
