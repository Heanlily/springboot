package com.mercury.SpringBootRESTDemo.dao;

import com.mercury.SpringBootRESTDemo.bean.Sample;
import org.springframework.data.jpa.repository.JpaRepository;

//CRUD sample
//1st generic type: entity class
//2nd generic type: Primary key(id)
public interface SampleDao extends JpaRepository<Sample,String> {

}

//we are creating an interface which extends data JPA's interface
//then spring data jpa will automatically create a concrete class to
//implement our interface(SampleDao)
//in the concrete class, Spring data JPA will provide implementation
//for CRUD operation in database using Hibernate
//after class will be created, spring will automatically create an object in the
//container
//Now in the spring ioc container, we have a sampleDao object

//Spring Data Jpa -> hibernate -> SQL