package com.mercury.SpringBootRESTDemo.dao;

import com.mercury.SpringBootRESTDemo.bean.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductDao extends JpaRepository<Product,Long> {
    // where price>=400
    //JPA Query lookup: you must follow naming convention
    //JPA will read your method name and try to understand it
    //if you follow the correct naming convention, jpa will generate corgresponding DAO method
    List<Product> findByPriceGreaterThanEqual(int minPrice);

    //if you don't want to follow naming convention for instructing JPA to generate DAO method
    //you can use custon query
    // name contain iphone,price>400, stock is an even number

    //get the max price for all products
    //JPA can't understand below method
    //custom query
    //SQL: SELECT max(price) FROM PRODUCT
    @Query("select max(p.price) from Product p")
    int getMaxPrice();

    //get products with stock under 200
    @Query("select p from Product  p where p.stock < :stock")
    List<Product> getProductWithLowStock(@Param("stock") int stock);
}
