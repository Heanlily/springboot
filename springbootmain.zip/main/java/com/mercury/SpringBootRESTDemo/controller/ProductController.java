package com.mercury.SpringBootRESTDemo.controller;

import com.mercury.SpringBootRESTDemo.bean.Product;
import com.mercury.SpringBootRESTDemo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    ProductService productService;

    //GET /products?minPrice =  400
    @GetMapping
    public List<Product> getProducts(@RequestParam(name = "minPrice",required = false) Integer minPrice) {
        if(minPrice != null) { //return products with price greater than min price
            return productService.getProductsAboveMinPrice(minPrice);
        }else {
            return productService.getAllProducts();
        }

    }

    //GET /product/2
    //path variable
    @GetMapping("/{id}")
    public Product getProduct(@PathVariable("id") long id) {
        return productService.getOneProductById(id);
    }



}
