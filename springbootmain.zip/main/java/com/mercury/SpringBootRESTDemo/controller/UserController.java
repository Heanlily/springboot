package com.mercury.SpringBootRESTDemo.controller;

import com.mercury.SpringBootRESTDemo.bean.User;
import com.mercury.SpringBootRESTDemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Max;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    UserService userService;
    @GetMapping
    public List<User> getUsers() {
        return userService.getAllUser();
    }
    @PostMapping
    public String postUsers(@RequestBody User user) {
        boolean result = userService.addOneUser(user);
        if(result) {
            return "User has been added";
        }else {
            return "User has not been added";
        }
    }

}
