package com.mercury.SpringBootRESTDemo.controller;

import com.mercury.SpringBootRESTDemo.bean.Sample;
import com.mercury.SpringBootRESTDemo.dao.SampleDao;
import com.mercury.SpringBootRESTDemo.service.SampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@Controller
//@ResponseBody
@RestController // = 上面两个综合
@RequestMapping("/samples")
public class SampleController {
    @Autowired
    SampleDao sampleDao;

    @Autowired
    SampleService sampleService;

    //GET /samples
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public List<Sample> getSamples() {
        return sampleService.getAllSamples();
    }

    //POST /samples
    //request body
    //extract json data as a java object:jackson
    @PostMapping
    public String postSamples(@RequestBody Sample sample) {
        boolean result = sampleService.addOneSample(sample);
        if(result){
            return "Sample added";
        }else{
            return "Sample not added";
        }
    }


}
