package com.mercury.SpringBootRESTDemo.controller;

import com.mercury.SpringBootRESTDemo.bean.Order;
import com.mercury.SpringBootRESTDemo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
//@RequestMapping("/orders")
public class OrderController {
    @Autowired
    OrderService orderService;
    //GET /orders
    @GetMapping("/orders")
    //GET /recent-order
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    public List<Order> getOrders() {
        return orderService.getAllOrders();
    }
}
