package com.mercury.SpringBootRESTDemo.interceptor;

import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.logging.Handler;

//log whoever access specific APIS
@Component
public class WhoAccessedInterceptor extends HandlerInterceptorAdapter {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //System.out.println(request.getRemoteAddr()+"access API"+request.getRequestURI());
        //192.168.1.20 accessed API
        return super.preHandle(request, response, handler);

    }

    //postHandle: do sth after response is sent back by controller
    
}
